class Character < ApplicationRecord
end
